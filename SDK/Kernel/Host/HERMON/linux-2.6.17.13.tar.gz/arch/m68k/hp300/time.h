extern void hp300_sched_init(irqreturn_t (*vector)(int, void *, struct pt_regs *));
extern unsigned long hp300_gettimeoffset (void);


