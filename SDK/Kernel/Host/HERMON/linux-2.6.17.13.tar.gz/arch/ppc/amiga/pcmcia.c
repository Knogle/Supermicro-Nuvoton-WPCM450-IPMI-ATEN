#include "../../m68k/amiga/pcmcia.c"
